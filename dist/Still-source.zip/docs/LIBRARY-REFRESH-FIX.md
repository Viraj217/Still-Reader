# 0.1.3 — download status and library updates

Library rows previously captured the initial state and were never updated or removed. The books list was loaded once and not refreshed after background completion. Multiple screen entries also attached duplicate download observers. A repeated unique request could be discarded by KEEP, while the dialog observed its unused UUID.

Now a single Activity observer tracks downloads. Active rows update on progress, finished rows disappear, failed rows show their error, and terminal transitions reload library metadata. Returning to the Activity refreshes the library. Dialogs observe the accepted unique job instead of assuming a newly submitted UUID was accepted.

Finalized, content-addressed EPUB/PDF files orphaned by the prior Android 9 registration error are recovered when opening the library. Recovery validates complete files, confirms the SHA-256 filename and imports EPUB title/creator metadata or an explicit unavailable-title PDF label. It ignores partial files. Invalid files are retained and logged, not registered or deleted.

Backend suite, assembleDebug and lintDebug passed. APK signature verified. Frontend behavior remains for physical tablet confirmation; no UI tests or emulator used. Install over existing app without clearing data so recovery can access completed files.
