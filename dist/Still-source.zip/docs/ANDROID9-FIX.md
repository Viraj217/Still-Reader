# 0.1.2 — Android 9 library registration fix

Reported: `still.app.Store cannot be cast to java.lang.AutoCloseable` after download.

The API 35 SDK declares SQLiteOpenHelper implements AutoCloseable. Android 9's class does not implement that interface. Kotlin's `Store(...).use` therefore inserted a cast which fails before registration on Android 9. Explicit try/finally now invokes Store.close directly on both success and failure. Compiled bytecode checked with javap confirms direct calls. No schema/data changes.

Android 9 source inspected:
https://github.com/aosp-mirror/platform_frameworks_base/blob/android-9.0.0_r1/core/java/android/database/sqlite/SQLiteOpenHelper.java

Also checked Android 9 PdfRenderer and Page: both implement AutoCloseable, so their use blocks are compatible.

Build, backend checks and lint succeeded; signature verified. No device/emulator executed. Install the update without uninstalling; retry the affected download to register the book.
