# Verification report — 2026-11-06

## Build

- `:app:assembleDebug`: successful. `dist/Still-debug.apk`, signed debug build.
- APK signature: v2 verified by Android SDK apksigner; one signer.
- Manifest: `org.still.reader`, version 0.1.0, minSdk 28, target/compile SDK 35.
- `:app:lintDebug`: successful, **0 errors / 19 warnings**. Warnings include newer dependency releases, English strings, draw allocations, backup configuration for newer Android, and unused transitive BouncyCastle trust-manager implementations. Still's OkHttp client uses standard platform TLS verification; no trust-all manager is installed by app code. See lint-results.txt.
- No emulator, device launch, UI automation, screenshots, visual tools or browser frontend tests.

## Automated backend tests

Final run: **24 passed, 0 failed, 2 opt-in live tests skipped**. CoreTest 16, MoreTest 7, SampleTest 1. The sample test revalidated downloaded files using current code, including EPUB package/manifest/spine presence and archive integrity. Test reports: test-summary.json and unit-tests-final.log.

Coverage: Unicode normalization, ISBN identification, ranking, edition-preserving deduplication, 404, 429/500 retries, redirects/loops, invalid MIME claims/HTML-as-PDF, unknown length, response bounds, cancellation, private-address and scheme rejection, partial-provider failures, concurrent search isolation, metadata caching, malformed/empty responses, no-response timeout, atomic downloads, duplicate content, resumed ranges, ignored ranges, incomplete PDF rejection, EPUB CRC/structure/path checks.

The no-response/disconnection fixture verifies cancellation of an unavailable connection; it does not simulate every device-level Wi-Fi failure. ZIP validation is not exhaustive fuzzing. No Android reader runtime tests were executed.

`scripts/check_database.py`: actual production CREATE statements exercised with desktop SQLite. Progress and ink survive close/reopen; deleting a book cascades to its marks. This does not test Android SQLiteOpenHelper lifecycle.

## Live public network evidence

- Internet Archive: real metadata; separate assertion-based integration passed and produced a verified matching Pride and Prejudice result in **8,176.50 ms**.
- Crossref: real filtered endpoint response; **5 explicitly open-license records in 960.58 ms** for “open science.” This is metadata latency, not a claim of five verified files.
- Gutenberg EPUB: **136,756 bytes**, full archive validation, package title “Alice's Adventures in Wonderland”, 21 ZIP entries. Probe/download/integrity sequence **3,479 ms**.
- W3C PDF: **13,264 bytes**, signature/end-marker check, SHA-256 recorded; Poppler pdfinfo confirms **1 page**, unencrypted, no JavaScript. Probe/download/integrity sequence **676 ms**. Actual app page-count code uses Android PdfRenderer; it was compiled, not executed.
- Gutendex: exact title, author, ambiguous title, Unicode title and missing-result requests all timed out (20–54 seconds). ISBN queries are intentionally unsupported by this provider and return no candidates without a request; the harness's ISBN PASS is not a successful network call.
- Open Library: live search metadata returned; not enabled as a download source (edition-access mapping needs additional work).
- Brave: implemented from official API contract, **not live-tested without a key**. OPDS: parser implemented; no configured public feed was live-tested.

See live-results.txt, live-extended.txt, live-integration.log, pdf-sample-info.txt and API-RESEARCH.md. The broad live harness logs individual external failures without failing its test method; the separate QuickLiveTest genuinely asserted a verified result and passed.

## Performance evidence and limits

Latest build benchmark: 10,000 metadata records deduplicated to 500 works in **80.78 ms** (see build-and-tests.log). This is one JVM run, not a statistically rigorous tablet benchmark. The final additional test run can show a different warm-up-dependent value.

Metadata cache test confirms two identical queries execute the underlying provider once. HTTP/download body buffers are bounded; PDF bitmap allocation is capped at approximately 10.1 MiB per rendered bitmap. This cap is an implementation bound, **not a measured process-memory result**. Peak app RSS, cold-start latency, page-turn speed and battery consumption require the physical tablet. See IMPLEMENTATION.md for targets and checklist.

## Acceptance status

Implemented and build-checked: library/discovery/settings/reader screens, native navigation, optional general web adapter, arbitrary public URL resolver, progressive verification, cancellation, persisted jobs, resumable downloads, offline files, reading progress, EPUB selection highlights, PDF ink/marker strokes, notes/bookmarks, annotation JSON export.

Not fully met: unlimited no-key web search; universal sample/preview identification; all requested metadata fields; comprehensive work/edition grouping; direct PDF on-page text selection; embedded PDF annotation export; continuous PDF scrolling; primary SD storage; fully standards-compliant robots parsing; broad source catalog coverage; runtime UI/device validation. This is a compiled first version with these explicit gaps, not full acceptance of every requirement in the master prompt.
