# Implementation and verification boundaries

## Architecture

Two Gradle modules: `core` (plain JVM discovery/network/download logic) and `app` (native Views, SQLite, WorkManager, readers). The `Provider` interface permits additional catalogs. Gutendex, Archive, Crossref, optional OPDS and Brave feed a concurrent flow. Failures remain isolated; collectors receive progressive verified editions and cancel their preceding search. Exact normalized titles dominate ranking. Author tokens and ISBN metadata contribute. Deduplication deliberately keeps language, edition and ISBN boundaries; it can under-merge incomplete metadata.

File verification uses anonymous GET, up to six redirects, bounded 64 KiB inspection, PDF magic or EPUB ZIP/mimetype evidence. No HEAD dependency. Document sizes come from response headers/Content-Range or completed bytes. Unknown page counts are displayed explicitly; local PDFs get the platform parser's actual count. Metadata candidates are cached for one hour on disk (100 entries); cached availability is never trusted. HTTP cache is 16 MiB. No fabricated ratings, statistics, covers or sample production records.

Downloads stream in 32 KiB blocks with a 256 MiB default limit (16–512 MiB configurable), free-space checks, validators and range resume, fsync, SHA-256 identity and same-directory atomic rename. WorkManager persists jobs and retries recoverable IO failures. A cancelled job retains its partial file; submitting the same source again resumes. An ignored range restarts safely. EPUB ZIP CRCs, paths, sizes and expansion ratios are checked. PDF header/end marker plus Android parser acceptance gate library registration. External-folder backups use persisted SAF grants; active books stay internal.

SQLite schema v1 has books, progress, marks, indexed book-to-annotation relationships and foreign-key deletion. WorkManager has its own persistent job database. No schema change has yet occurred; upgrades fail explicitly rather than discarding annotations. Full-library backup/restore and future migrations need implementation before a schema version bump.

## Readers

Readium 3.0.3 parses and renders EPUB with native fragment integration. Typography, line height, margins, themes, scroll/page modes, TOC, internal links, locator progress, bookmarks, selected-text highlights and notes are wired. The rendered cache copy removes scripts, event handlers and active embedded elements and adds a restrictive CSP. The original remains intact. Book search currently returns matching **chapters**, not precise occurrences. Annotations export as locator JSON. Sanitized EPUB compatibility needs device verification, particularly publisher CSS/fixed layouts.

PDF rendering uses Android PdfRenderer with one bitmap capped at 1200×2200 (~10.1 MiB), pinch zoom/pan, and directional page gestures. PDFBox Android supplies text extraction/search using a disk-backed scratch setting. Text selection is in a selectable page-text dialog, not directly over the rendered page. Scans report no text layer; no OCR. Highlights are freehand marker strokes, not text-anchored quadrilaterals. Notes/bookmarks and ink are SQLite records; points and stroke widths use normalized top-left coordinates. Exports are portable JSON, **not embedded PDF annotations**. Continuous multi-page scrolling is not implemented. Zoom enlarges the bounded bitmap; high-zoom text can soften.

## Dependencies / licenses

- Kotlin and kotlinx.coroutines: Apache-2.0.
- AndroidX Fragment/Lifecycle/WorkManager: Apache-2.0.
- OkHttp/Okio: Apache-2.0.
- jsoup: MIT.
- Readium Kotlin 3.0.3: BSD-3-Clause; includes Readium CSS and its bundled license notices.
- PDFBox Android 2.0.27.0: Apache-2.0; no optional JPEG2000 codec included.
- org.json (JVM core tests; Android supplies runtime implementation): public-domain JSON-java release.
- JUnit/MockWebServer: development/test only. Toolchain distributions remain outside source.

Readium's actual pinned source/documentation was inspected before integration. minSdk is 28, compile/target SDK 35, JDK 17, desugaring enabled. No native library ABI restriction.

## Important gaps

This first version does not satisfy every original acceptance item:

- No unlimited unauthenticated general web-search service exists in this build. Broad search requires a Brave key; otherwise catalogs plus arbitrary pasted pages/files are available. The configured OPDS feed has one-page XML support only.
- HTTP accessibility and magic bytes cannot establish that every arbitrary PDF is a complete book rather than a sample or wrongly described file. No universal full-text/metadata consistency classifier is implemented. Search results state header verification; complete integrity is checked after download. No promise of universal preview exclusion is warranted.
- Gutendex failed live requests in this environment. Public API availability varies. No service is falsely represented as guaranteed.
- Metadata fields are incomplete across providers: publisher, exact edition-page counts and comprehensive translation grouping are not fully modeled. Crossref requires explicit Creative Commons licensing; metadata without such evidence is excluded.
- Robots handling is conservative and incomplete (not a full RFC parser); Retry-After HTTP dates are not parsed. Per-host timing is per Net instance, not a process-wide cross-worker quota. DNS rebinding defenses rely on validated addresses returned to OkHttp.
- File parsing is bounded but is not a complete adversarial-document sandbox. System WebView/PDF parser security updates on the old tablet still matter. Downloaded document scripts are removed from EPUB render copies; PDF JavaScript is not executed by PdfRenderer.
- Optional Brave key is private app preference data, excluded from backup, but not encrypted with Android Keystore.
- Active library cannot be relocated to SD; SAF currently mirrors downloaded files only. Folder copies do not include the annotation database. Interrupted SAF copies can leave incomplete backup documents.
- No on-device measurements or runtime UI claims. Views compile, but gesture interactions, selection, lifecycle and visual layout need physical-tablet testing. No instrumentation/UI/emulator execution occurred.

## Physical Lenovo Tab M10 checklist

1. Install APK; test launch, font scaling, portrait/landscape and library list/grid usability.
2. Search Archive and a public URL; test optional Brave/OPDS independently with authorized credentials/endpoints.
3. Download both formats; interrupt Wi-Fi, restart app, cancel and resume, and simulate insufficient space.
4. Read both offline; rotate, background/kill/reopen and verify positions and all annotation types survive.
5. EPUB: select text, save note/highlight, change typography, follow TOC/internal links, search chapters, export JSON.
6. PDF: check drawing alignment at zoom levels/orientations, erasing via annotation deletion, scans without text, search, selection dialog and export JSON.
7. Test SAF SD card selection, removal/reinsertion, denied/revoked grants and backup failures.
8. Measure cold start (<2 s target), cached library response (<150 ms target), page turn (<250 ms target), and peak RSS (<180 MiB target). These are targets, **not measured results**.
